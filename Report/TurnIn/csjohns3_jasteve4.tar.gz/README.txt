clock name: clock
top level module: top
testbench name: top_testbench
